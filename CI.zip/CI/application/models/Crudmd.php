<?php
class Crudmd extends CI_Model{

function __construct() {
 $this->load->database();
parent::__construct();
}/*
function Crudmd(){
parent::Model();
}*/

function form_insert($data){
print_r($data);
$this->db->insert('employee', $data);

}

 public function get_data()  
      {   
         //data is retrive from this query  
         $query = $this->db->get("employee");  
         return $query;  
      } 

 public function get_by_id($id=0){
            if($id === 0){
              $query = $this->db->get('employee');
              return $query->row_array();
            }
            $query = $this->db->get_where('employee',array('EmpId'=> $id));
            return $query->row_array();
          }

          public function delete($id){
            $this->db->where('EmpId',$id);
            return $this->db->delete('employee');
          }
		  
		  public function set_data($id = 0)
    {
        $this->load->helper('url');
 
        //$slug = url_title($this->input->post('title'), 'dash', TRUE);
 
        $data = array(
            'Fname' => $this->input->post('Fname'),
			'Lname' => $this->input->post('Lname'),
            'DOB' => $this->input->post('DOB'),
			'Mobile' => $this->input->post('Mobile'),
			'Email' => $this->input->post('Email'),
			'Address' => $this->input->post('Address'),
			'joinDate' => $this->input->post('joinDate'),
			'Salary' => $this->input->post('Salary')
        );
        
        if ($id == 0) {
            return $this->db->insert('employee', $data);
        } else {
            $this->db->where('EmpId', $id);
            return $this->db->update('employee', $data);
        }
    }
	  
}
?>
