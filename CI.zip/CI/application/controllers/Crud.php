<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Crud extends CI_Controller {

   function __construct() {
   parent::__construct();
   
   $this->load->model('crudmd');
}
 public function index()
   {
 
  $this->load->view('create');
  	
  }
  public function create(){
	$this->load->database();
	print_r($_POST);
	$this->crudmd->form_insert($_POST);
	
   }
   
   public function load()
   {
   //$data=$this->crudmd->get_data();

//$result=$data->result();
//print_r($result);
        $this->load->database();  
         //load the method of model  
         $data['get_data']=$this->crudmd->get_data();  
         //return the data in view  
         $this->load->view('crudview', $data);  

   }
   public function delete($id){
            $this->load->database();
            
            // print_r($id);

            $id = $this->uri->segment(3);
            if(empty($id)){
              show_404();
            }
            $row = $this->crudmd->get_by_id($id);

            $this->crudmd->delete($id);
            redirect(base_url(). 'index.php/crud');
          }


public function edit()
    {
        $id = $this->uri->segment(3);
        
        if (empty($id))
        {
            show_404();
        }
        
        $this->load->helper('form');
        $this->load->library('form_validation');
		 //$data['news_item'] = $this->crudmd->get_by_id($id);
		 // $this->load->view('editcd', $data);
            $data['edit_data']=$this->crudmd->get_by_id($id);
            
            $this->load->view('editcd', $data);
			$this->crudmd->set_data($id);
          redirect( base_url() . 'index.php/crud');
        }
    

}

?>
