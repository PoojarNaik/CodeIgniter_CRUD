<html>
<body>
 <?php
 $this->load->helper('form');
 
 echo form_open('crud/edit/'.$edit_data['EmpId']); ?>
     <table>
	 <tr>
            <td><label for="text">Fname</label></td>
            <td><input type="text" name="Fname"><?php echo $edit_data['Fname'] ?></td>
        </tr>
        <tr>
            <td><label for="title">LName</label></td>
            <td><input type="input" name="Lname" size="50" value="<?php echo $edit_data['Lname'] ?>" /></td>
        </tr>
        <tr>
            <td><label for="text">DOB</label></td>
            <td><input type="text" name="DOB" ><?php echo $edit_data['DOB'] ?></td>
        </tr>
		 <tr>
            <td><label for="text">Mobile</label></td>
            <td><input type="text" name="Mobile"><?php echo $edit_data['Mobile'] ?></td>
        </tr>
		 <tr>
            <td><label for="text">Email</label></td>
            <td><input type="text" name="Email"><?php echo $edit_data['Email'] ?></td>
        </tr>
		 <tr>
            <td><label for="text">Address</label></td>
            <td><input type="text" name="Address"><?php echo $edit_data['Address'] ?></td>
        </tr>
		 <tr>
            <td><label for="text">joinDate</label></td>
            <td><input type="text" name="joinDate"><?php echo $edit_data['joinDate'] ?></td>
        </tr>
		 <tr>
            <td><label for="text">Salary</label></td>
            <td><input type="text" name="text"><?php echo $edit_data['Salary'] ?></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="submit" value="Update" /></td>
        </tr>
    </table>
</form>
</body>
</html>