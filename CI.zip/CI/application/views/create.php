<html>
<body>

<p><a href="<?php echo site_url('crud/load'); ?>">Home</a> </p>
<form action="create" method="post">
  <table>
  <tr>
      <td>Employee id</td><td><input type="text" name="EmpId"></td></tr>
    <td>First Name</td><td><input type="text" name="Fname"></td></tr>
      <td>Last Name Name</td><td><input type="text" name="Lname"></td></tr>
        <td>DOB</td><td><input type="text" name="DOB"></td></tr>
          <td>Mobile</td><td><input type="text" name="Mobile"></td></tr>
            <td>Email Id</td><td><input type="text" name="Email"></td></tr>
              <td>Adresss</td><td><input type="text" name="Address"></td></tr>
                <td>Join date</td><td><input type="text" name="joinDate"></td></tr>
                  <td>salary</td><td><input type="text" name="Salary"></td></tr>
                </table>
                <input type="submit" value="submit"  data-toggle="tooltip" title="Click here">
              </form>
</body>
</html
