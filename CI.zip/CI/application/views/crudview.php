<html>
<body>
<table border='1' cellpadding='4'>
    <tr>
        <td><strong>EmpId</strong></td>
        <td><strong>Fname</strong></td>
        <td><strong>Lname</strong></td>
		<td><strong>DOB</strong></td>
        <td><strong>Mobile</strong></td>
        <td><strong>Email</strong></td>
		<td><strong>Address</strong></td>
        <td><strong>joinDate</strong></td>
        <td><strong>Salary</strong></td>
		 <td><strong>Action</strong></td>
    </tr>
	 
<?php  if($get_data->num_rows()>0){
foreach ($get_data->result() as $row): ?>
        <tr>
			<td><?php echo $row->EmpId; ?></td>
            <td><?php echo $row->Fname; ?></td>
            <td><?php echo $row->Lname; ?></td>
			<td><?php echo $row->DOB; ?></td>
			<td><?php echo $row->Mobile; ?></td>
			<td><?php echo $row->Email; ?></td>
			<td><?php echo $row->Address; ?></td>
			<td><?php echo $row->joinDate; ?></td>
			<td><?php echo $row->Salary; ?></td>
			
            <td>
                <a href="<?php echo site_url('crud/edit/'.$row->EmpId); ?>">Edit</a> | 
                <a href="<?php echo site_url('crud/delete/'.$row->EmpId); ?>" onClick="return confirm('Are you sure you want to delete?')">Delete</a>
            </td>
        </tr>
	
<?php endforeach; }?>
</table>
</body>
</html>